USE crisisflow_new;

INSERT INTO Resource_Type (resource_type_id, type_name, description)
VALUES
(1, 'Ambulance', 'Medical transportation and emergency evacuation'),
(2, 'Fire Rescue Team', 'Fire suppression and rescue operations'),
(3, 'Medical Team', 'On-site emergency medical assistance'),
(4, 'Search and Rescue Team', 'Rescue of trapped or missing people'),
(5, 'Disaster Response Team', 'General disaster response and support');