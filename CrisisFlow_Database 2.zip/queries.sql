USE crisisflow_new;

-- View all resource types
SELECT *
FROM Resource_Type;

-- View all resources
SELECT *
FROM Resource;

-- View all emergencies
SELECT *
FROM Emergency;

-- View all allocations
SELECT *
FROM Allocation;

-- View available resources
SELECT
    r.resource_id,
    r.resource_name,
    rt.type_name AS resource_type,
    r.capacity,
    r.location,
    r.status
FROM Resource r
JOIN Resource_Type rt
    ON r.resource_type_id = rt.resource_type_id
WHERE r.status = 'Available';

-- View emergencies ordered by severity
SELECT
    e.emergency_id,
    e.disaster_type,
    e.location,
    e.severity,
    e.people_affected,
    rt.type_name AS required_resource_type,
    e.priority,
    e.status
FROM Emergency e
LEFT JOIN Resource_Type rt
    ON e.required_resource_type_id = rt.resource_type_id
ORDER BY e.severity DESC, e.people_affected DESC;

-- View allocation details
SELECT
    a.allocation_id,
    a.emergency_id,
    a.resource_id,
    a.assigned_time,
    a.status
FROM Allocation a;