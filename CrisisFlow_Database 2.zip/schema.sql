USE crisisflow_new;

CREATE TABLE Resource_Type (
    resource_type_id INT AUTO_INCREMENT PRIMARY KEY,
    type_name VARCHAR(100) NOT NULL,
    description VARCHAR(255)
);

CREATE TABLE Resource (
    resource_id INT AUTO_INCREMENT PRIMARY KEY,
    resource_type_id INT NOT NULL,
    resource_name VARCHAR(100) NOT NULL,
    capacity INT,
    location VARCHAR(255),
    status VARCHAR(30) DEFAULT 'Available',

    FOREIGN KEY (resource_type_id)
        REFERENCES Resource_Type(resource_type_id)
);

CREATE TABLE Emergency (
    emergency_id INT AUTO_INCREMENT PRIMARY KEY,
    disaster_type VARCHAR(50) NOT NULL,
    location VARCHAR(255) NOT NULL,
    severity INT NOT NULL,
    people_affected INT NOT NULL,
    required_resource_type_id INT,
    report_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    priority VARCHAR(20),
    status VARCHAR(30) DEFAULT 'Reported',

    FOREIGN KEY (required_resource_type_id)
        REFERENCES Resource_Type(resource_type_id)
);

CREATE TABLE Allocation (
    allocation_id INT AUTO_INCREMENT PRIMARY KEY,
    emergency_id INT NOT NULL,
    resource_id INT NOT NULL,
    assigned_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(30) DEFAULT 'Assigned',

    FOREIGN KEY (emergency_id)
        REFERENCES Emergency(emergency_id),

    FOREIGN KEY (resource_id)
        REFERENCES Resource(resource_id)
);