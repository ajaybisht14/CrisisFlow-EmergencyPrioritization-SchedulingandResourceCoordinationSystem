# CrisisFlow Database Design

## 1. Database Overview

The CrisisFlow database is designed to support emergency and disaster resource management.

The database contains four main tables:

1. Resource_Type
2. Resource
3. Emergency
4. Allocation

The database is currently created locally using MySQL.

---

## 2. Tables

### Resource_Type

Stores the different types of resources available for disaster management.

Columns:
- resource_type_id – Primary key
- type_name – Name of the resource type
- description – Description of the resource type

The table contains five predefined resource types:
- Ambulance
- Fire Rescue Team
- Medical Team
- Search and Rescue Team
- Disaster Response Team

---

### Resource

Stores information about individual resources.

Columns:
- resource_id – Primary key
- resource_type_id – Foreign key referencing Resource_Type
- resource_name – Name of the resource
- capacity – Capacity of the resource
- location – Current location
- status – Current availability status

The table is currently empty.

---

### Emergency

Stores information about reported emergencies.

Columns:
- emergency_id – Primary key
- disaster_type – Type of disaster
- location – Emergency location
- severity – Severity level
- people_affected – Number of affected people
- required_resource_type_id – Foreign key referencing Resource_Type
- report_time – Time when the emergency was reported
- priority – Priority of the emergency
- status – Current emergency status

The table is currently empty.

---

### Allocation

Stores the allocation of resources to emergencies.

Columns:
- allocation_id – Primary key
- emergency_id – Foreign key referencing Emergency
- resource_id – Foreign key referencing Resource
- assigned_time – Time when the resource was assigned
- status – Allocation status

The table is currently empty.

---

## 3. Relationships

The database uses foreign keys to maintain relationships between tables.

- Resource_Type → Resource
- Resource_Type → Emergency
- Emergency → Allocation
- Resource → Allocation

This allows resources to be associated with their resource types and allows resources to be allocated to emergencies.

---

## 4. Current Database State

| Table | Current Data |
|---|---|
| Resource_Type | 5 records |
| Resource | Empty |
| Emergency | Empty |
| Allocation | Empty |

---

## 5. Conclusion

The CrisisFlow database provides the basic relational structure required for resource type management, resource management, emergency management, and resource allocation.

The database is ready for further application development and integration with the C++ application.